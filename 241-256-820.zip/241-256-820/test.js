       /*
       console.log('Hello world');
       console.log('Hello world');
       console.log('Hello ' + 'Waritthon');
       
       //ตัวแปร
       let name = 'Pun' //let คือการประกาศตัวแปรที่มีขอบเขตใน block ที่ประกาศ
       console.log(name)
       let firstname = 'Waritthon'
       let lastname = 'Santikarn'
       alert(firstname +' '+ lastname) 
       alert(10)  // alert ข้อความเเจ้งเตือน

       let age = 12
       console.log(age)

       //console.log(typeof name) เช็คชนิดของตัวแปร
       console.log(10/2)
       let name2 = prompt('What is your name?')
       console.log("Hello ",name2)
       */

       //let lotto = prompt('Enter number of lotto: ')
       //document.getElementById('result').innerHTML = Math.floor(Math.random() * 100);

       console.log("4" === 4)
       console.log("4" == 4)